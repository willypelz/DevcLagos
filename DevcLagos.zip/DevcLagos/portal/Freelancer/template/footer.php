      <?php echo $google_analytics; ?> 
      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Version 2.0
        </div>
        <!-- Default to the left -->
        <strong><a href="index.php"><?php echo escape($title); ?></a> <?php auto_copyright('2016','All Rights Reserved'); ?>.</strong>
      </footer>
      